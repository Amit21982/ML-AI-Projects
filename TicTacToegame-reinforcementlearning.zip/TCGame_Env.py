from gym import spaces
import numpy as np
import random
import collections
import pickle

class TicTacToe:
    """
    Simulator environment class for training the agent for the game
    """
    def __init__(self):
        """
        Initialize the values
        """
        self.board = [0]*9
        self.odd_player = None 
        self.even_player = None 
        self.States_track = collections.defaultdict(dict)

   #Reset the board
    def reset(self):
        """
        Wipe the board to restart the game
        """
        self.board = [0]*9
       
        
    def check_board_return_reward(self):
        """
        Check board present condition to see if agent has won
        Check for Rows, Columns and diagonal values
        Check for draws and return reward accordingly
        """
        for i in range(3):
            if (self.board[i * 3] + 
                self.board[i * 3 + 1] + 
                self.board[i * 3 + 2]) == 15:
                return 1.0, True
            
         #Columns rewards
        for i in range(3):
            if (self.board[i + 0] + 
                self.board[i + 3] + 
                self.board[i + 6]) == 15:
                return 1.0, True
        
         #Diagonals
        if (self.board[0] + 
            self.board[4] + 
            self.board[8]) == 15:     
            return 1.0, True
        
        if (self.board[2] + 
            self.board[4] + 
            self.board[6]) == 15:
            return 1.0, True

        # Draw condition
        if not any(space == 0 for space in self.board):
            return 0.0, True

        return 0.0, False

    def possible_moves(self):
        """
        Return list of moves where agent can continue
        """
        vacant_moves =  [moves + 1 for moves, spot in enumerate(self.board) if spot == 0]
        return vacant_moves

   
    def pick_move(self, isODD):
        """
        Pick the next move randomly depending on odd or even player
        """
        if(isODD):
            self.odd_player.options = random.sample(self.odd_player.options, len(self.odd_player.options))
            return self.odd_player.options.pop()
        else:
            self.even_player.options = random.sample(self.even_player.options, len(self.even_player.options))
            return self.even_player.options.pop()
    
    def initialise_tracking_states(self):
        sample_q_values = [((0, 0, 0, 0, 0, 0, 0, 0, 0), 1),
                           ((0, 0, 0, 0, 0, 0, 0, 0, 0), 8),
                           ((0, 0, 6, 0, 0, 0, 0, 5, 0), 2),
                           ((0, 2, 0, 0, 8, 0, 0, 3, 1), 6),
                           ((0, 4, 2, 5, 0, 0, 3, 0, 0), 1),
                           ((8, 0, 0, 0, 0, 0, 0, 9, 0), 5),
                           ((0, 4, 7, 0, 0, 0, 0, 0, 0), 5)]   
        for q_values in sample_q_values:
            state = q_values[0]
            action = q_values[1]
            self.States_track[state][action] = []    #this is an array which will have appended values of that state-action pair for every 2000th episode   
 
                
    def save_tracking_states(self, odd_player):
        for state in self.States_track.keys():
            for action in self.States_track[state].keys():
                if (state,action) in odd_player.Q.keys() and (odd_player.Q[(state,action)]) > 0:
                    self.States_track[state][action].append(odd_player.Q[(state,action)])
                   
               
    def step(self, isODD, move):
        """
        Wrapper function to pick the next move and return reward
        """
        self.board[move-1]= self.pick_move(isODD)
        reward, done = self.check_board_return_reward()
        return reward, done

    def start_training(self, odd_player, even_player, episode_count, odd=True):
        """
        Entry function to train the agent in simulator environment
        """
        self.odd_player=odd_player
        self.even_player=even_player
        print ("Training Started")
        threshold = 10000
        for i in range(episode_count):
            self.odd_player.start()
            self.even_player.start()
            self.reset()
            done = False

            # We will start with the odd player. Here are the steps 
            # we will choose the move based on epsilon greedy strategy which is also decaying
            # We will calculate the reward for the move and this will also lead in terminating loop
            # once we have the reward and done state, we will update the Q states of agent
            # after every iteration we will switch the player
            isODD = odd
            
            if (i == threshold-1):        #at the 999th episode
                print('initialize tracking state')
                self.initialise_tracking_states()
            if ((i+1) % threshold) == 0:   #every 1000th episode\
                self.save_tracking_states(self.odd_player)
                
                
                    
            while not done:
                if isODD:
                    move = self.odd_player.epslion_greedy_strategy_with_decay(self.board, self.possible_moves())
                else:
                    move = self.even_player.epslion_greedy_strategy_with_decay(self.board, self.possible_moves())

                reward, done = self.step(isODD, move)
                
                if (reward == 1):
                    #If the reward is 1 then reward the odd or even player with 10 reward points
                    if (isODD):
                        self.odd_player.update_Q_states(10, self.board, self.possible_moves())
                        self.even_player.update_Q_states(-10, self.board, self.possible_moves())
                    else:
                        self.odd_player.update_Q_states(-10, self.board, self.possible_moves())
                        self.even_player.update_Q_states(10, self.board, self.possible_moves())
                elif (done == False): 
                    #The game is on so reward with normal -1
                    if (isODD):
                        self.odd_player.update_Q_states(-1, self.board, self.possible_moves())
                 
                else: 
                    # if game ends in draw
                    self.odd_player.update_Q_states(reward, self.board, self.possible_moves())
                    self.even_player.update_Q_states(reward, self.board, self.possible_moves())   
                isODD = not isODD  
        self.save_obj('States_tracked')      
        print ("Training is completed")
    
    def save_obj(self, name):
        obj = self.States_track
        with open(name + '.pkl', 'wb') as f:
            pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL) 
            
    def save_states(self):
        """
        Save states as pickle files
        """
        self.odd_player.save_Q_states("odd_q_states")
        self.even_player.save_Q_states("even_q_states")
        
    def get_q_values(self):
        """
        Return Q values for players
        """
        return self.odd_player.Q, self.even_player.Q