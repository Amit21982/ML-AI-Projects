
## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - verify_location
    - slot{"location": "pune"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "pune"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "amirasabot2020@gmail.com"}
    - slot{"emailid": "amirasabot2020@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - verify_location
    - slot{"location": "chennai"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "chennai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_3
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - verify_location
    - slot{"location": "delhi"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 0 to 300"}
    - slot{"price": "Rs. 0 to 300"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_4
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "coimbatore"}
    - slot{"location": "coimbatore"}
    - verify_location
    - slot{"location": "coimbatore"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 0 to 300"}
    - slot{"price": "Rs. 0 to 300"}
    - action_search_restaurants
    - slot{"location": "coimbatore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* deny
    - utter_goodbye
    - action_restart

## interactive_story_5
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "gurgaon"}
    - slot{"location": "gurgaon"}
    - verify_location
    - slot{"location": "gurgaon"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 0 to 300"}
    - slot{"price": "Rs. 0 to 300"}
    - action_search_restaurants
    - slot{"location": "gurgaon"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* deny
    - utter_goodbye
    - action_restart


## interactive_story_6
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "jalandhar"}
    - slot{"location": "jalandhar"}
    - verify_location
    - slot{"location": "jalandhar"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 0 to 300"}
    - slot{"price": "Rs. 0 to 300"}
    - action_search_restaurants
    - slot{"location": "jalandhar"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* deny
    - utter_goodbye
    - action_restart

## interactive_story_7
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bhopal", "cuisine":"north indian"}
    - slot{"location": "bhopal"}
    - verify_location
    - slot{"location": "bhopal"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "bhopal"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_8
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "belgaum", "cuisine":"north indian"}
    - slot{"location": "belgaum"}
    - verify_location
    - slot{"location": "belgaum"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "belgaum"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_9
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "ahmedabad", "cuisine":"south indian"}
    - slot{"location": "ahmedabad"}
    - verify_location
    - slot{"location": "ahmedabad"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 700 to 500000"}
    - slot{"price": "Rs. 700 to 500000"}
    - action_search_restaurants
    - slot{"location": "ahmedabad"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_10
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kolkata", "cuisine":"south indian"}
    - slot{"location": "kolkata"}
    - verify_location
    - slot{"location": "kolkata"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 700 to 500000"}
    - slot{"price": "Rs. 700 to 500000"}
    - action_search_restaurants
    - slot{"location": "kolkata"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_11
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "hyderabad", "cuisine":"mexican"}
    - slot{"location": "hyderabad"}
    - verify_location
    - slot{"location": "hyderabad"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "hyderabad"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_12
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore", "cuisine":"italian"}
    - slot{"location": "bangalore"}
    - verify_location
    - slot{"location": "bangalore"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_13
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "allahabad"}
    - slot{"location": "allahabad"}
    - verify_location
    - slot{"location": "allahabad"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "allahabad"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "amirasabot2020@gmail.com"}
    - slot{"emailid": "amirasabot2020@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_14
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "amritsar"}
    - slot{"location": "amritsar"}
    - verify_location
    - slot{"location": "amritsar"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "amritsar"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "amirasabot2020@gmail.com"}
    - slot{"emailid": "amirasabot2020@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_15
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - verify_location
    - slot{"location": "indore"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "amirasabot2020@gmail.com"}
    - slot{"emailid": "amirasabot2020@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_16
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "jabalpur"}
    - slot{"location": "jabalpur"}
    - verify_location
    - slot{"location": "jabalpur"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "jabalpur"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_17
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "jaipur"}
    - slot{"location": "jaipur"}
    - verify_location
    - slot{"location": "jaipur"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_18
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kanpur"}
    - slot{"location": "kanpur"}
    - verify_location
    - slot{"location": "kanpur"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 0 to 300"}
    - slot{"price": "Rs. 0 to 300"}
    - action_search_restaurants
    - slot{"location": "kanpur"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_19
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kochi"}
    - slot{"location": "kochi"}
    - verify_location
    - slot{"location": "kochi"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 0 to 300"}
    - slot{"price": "Rs. 0 to 300"}
    - action_search_restaurants
    - slot{"location": "kochi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_20
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kakinada"}
    - slot{"location": "kakinada"}
    - verify_location
    - slot{"location": "kakinada"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "kakinada"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_21
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kolhapur"}
    - slot{"location": "kolhapur"}
    - verify_location
    - slot{"location": "kolhapur"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "kolhapur"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_22
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kozhikode"}
    - slot{"location": "kozhikode"}
    - verify_location
    - slot{"location": "kozhikode"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "kozhikode"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_23
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "lucknow"}
    - slot{"location": "lucknow"}
    - verify_location
    - slot{"location": "lucknow"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "lucknow"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_24
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mathura"}
    - slot{"location": "mathura"}
    - verify_location
    - slot{"location": "mathura"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "mathura"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_25
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mathura"}
    - slot{"location": "mathura"}
    - verify_location
    - slot{"location": "mathura"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "mathura"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_26
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "goa"}
    - slot{"location": "goa"}
    - verify_location
    - slot{"location": "goa"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "goa"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_27
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mangalore"}
    - slot{"location": "mangalore"}
    - verify_location
    - slot{"location": "mangalore"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "mangalore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_28
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "meerut"}
    - slot{"location": "meerut"}
    - verify_location
    - slot{"location": "meerut"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "meerut"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_29
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mysore"}
    - slot{"location": "mysore"}
    - verify_location
    - slot{"location": "mysore"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "mysore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_30
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "nashik"}
    - slot{"location": "nashik"}
    - verify_location
    - slot{"location": "nashik"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 700 to 500000"}
    - slot{"price": "Rs. 700 to 500000"}
    - action_search_restaurants
    - slot{"location": "nashik"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_31
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "London"}
    - slot{"location": "London"}
    - verify_location
    - slot{"location": "London"}
    - slot{"location_supported": false}
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - verify_location
    - slot{"location": "Bangalore"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 700 to 500000"}
    - slot{"price": "Rs. 700 to 500000"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart


## interactive_story_32
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Lanka"}
    - slot{"location": "Lanka"}
    - verify_location
    - slot{"location": "Lanka"}
    - slot{"location_supported": false}
    - utter_ask_location
* restaurant_search{"location": "thrissur"}
    - slot{"location": "thrissur"}
    - verify_location
    - slot{"location": "thrissur"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 700 to 500000"}
    - slot{"price": "Rs. 700 to 500000"}
    - action_search_restaurants
    - slot{"location": "thrissur"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_33
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangla"}
    - slot{"location": "bangla"}
    - verify_location
    - slot{"location": "bangla"}
    - slot{"location_supported": false}
    - utter_ask_location
* restaurant_search{"location": "vadodara"}
    - slot{"location": "vadodara"}
    - verify_location
    - slot{"location": "vadodara"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 700 to 500000"}
    - slot{"price": "Rs. 700 to 500000"}
    - action_search_restaurants
    - slot{"location": "vadodara"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_34
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "hyderabad", "cuisine":"mexican", "price": "Rs. 300 to 700"}
    - slot{"location": "hyderabad"}
    - verify_location
    - slot{"location": "hyderabad"}
    - slot{"location_supported": true}
    - action_search_restaurants
    - slot{"location": "hyderabad"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart


## interactive_story_35
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore", "cuisine":"mexican", "price": "Rs. 300 to 700"}
    - slot{"location": "indore"}
    - verify_location
    - slot{"location": "indore"}
    - slot{"location_supported": true}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* send_email{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - utter_goodbye
    - action_restart

## interactive_story_36
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Delhi"}
    - verify_location
    - slot{"location": "Delhi"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Delhi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye

## interactive_story_37
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Delhi"}
    - verify_location
    - slot{"location": "Delhi"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Delhi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* dont_send_email
    - utter_goodbye

## interactive_story_38
* greet
    - utter_greet
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - verify_location
    - slot{"location": "Mumbai"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye


## interactive_story_39 ## only cuisine entered. User input - "show me lassi restaurants"
* greet
    - utter_greet
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_location
* greet{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - verify_location
    - slot{"location": "Delhi"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Delhi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye

## interactive_story_40 ## Only cuisine entered. User input - "show me dosa restaurants"
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_location
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - verify_location
    - slot{"location": "Chennai"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Chennai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - utter_goodbye

## interactive_story_41 ## Only cuisine entered. User input - "show me noodles restaurants"
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - verify_location
    - slot{"location": "pune"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "pune"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "kcmrocky@gmail.com"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "kcmrocky@gmail.com"}
    - utter_goodbye

## interactive_story_42 ## Only cuisine entered. User input - "show me burger restaurants"
* greet
    - utter_greet
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - verify_location
    - slot{"location": "Mumbai"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "More than Rs. 700"}
    - slot{"price": "More than Rs. 700"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* dont_send_email
    - utter_goodbye

## interactive_story_43 ## Only cuisine entered. User input - "show me pizzas restaurants"
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_location
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - verify_location
    - slot{"location": "kolkata"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "kolkata"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye

## interactive_story_44 ## Only cuisine entered. User input - "show me tacos restaurants"
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_location
* restaurant_search{"location": "Mysore"}
    - slot{"location": "Mysore"}
    - verify_location
    - slot{"location": "Mysore"}
    - slot{"location_supported": true}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Mysore"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye

## interactive_story_45 ## Synonym test case for only location entered.
* greet
    - utter_greet
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - verify_location
    - slot{"location": "Chennai"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Chennai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye

## interactive_story_46 ## Selected invalid city test case.
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "London"}
    - slot{"location": "London"}
    - verify_location
    - slot{"location": null}
    - slot{"location_supported": false}
    - verify_location
* restaurant_search{"location": "dubai"}
    - slot{"location": "dubai"}
    - verify_location
    - slot{"location": null}
    - slot{"location_supported": false}
    - utter_ask_location
* restaurant_search{"location": "rajkot"}
    - slot{"location": "rajkot"}
    - verify_location
    - slot{"location": "rajkot"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "rajkot"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye

## interactive_story_47 ## User had given only PRICE RANGE.
* greet
    - utter_greet
* restaurant_search{"price": "300 - 700"}
    - slot{"price": "300 - 700"}
    - utter_ask_location
* restaurant_search{"location": "ujjain"}
    - slot{"location": "ujjain"}
    - verify_location
    - slot{"location": "ujjain"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_search_restaurants
    - slot{"location": "ujjain"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "vishy007.geek@gmail.com"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "vishy007.geek@gmail.com"}
    - utter_goodbye


## interactive_story_price < 300
* greet
    - utter_greet
* restaurant_search{"location": "zinjhang"}
    - slot{"location": "zinjhang"}
    - verify_location
    - slot{"location": null}
    - slot{"location_supported": false}
    - utter_goodbye

## interactive_story_price_location_sendmail
* greet
    - utter_greet
* restaurant_search{"price": "Lesser than Rs. 300", "location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - slot{"price": "Lesser than Rs. 300"}
    - verify_location
    - slot{"location": "Mumbai"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"restaurant_exist": false}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "dwivedi.amit21982@gmail.com"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - utter_goodbye

## interactive_story_price_location_dontsendmail
* greet
    - utter_greet
* restaurant_search{"price": "Lesser than Rs. 300", "location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - slot{"price": "Lesser than Rs. 300"}
    - verify_location
    - slot{"location": "Mumbai"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"restaurant_exist": false}
    - utter_ask_email
* deny
    - utter_goodbye
    - action_restart

## interactive_story_price_sendmail
* greet
    - utter_greet
* restaurant_search{"price": "More than Rs. 700"}
    - slot{"price": "More than Rs. 700"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - verify_location
    - slot{"location": "pune"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_search_restaurants
    - slot{"location": "pune"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "dwivedi.amit21982@gmail.com"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - form{"name": null}
    - slot{"requested_slot": null}
    - utter_goodbye


## interactive_story_price_deny_mail
* greet
    - utter_greet
* restaurant_search{"price": "More than Rs. 700"}
    - slot{"price": "More than Rs. 700"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - verify_location
    - slot{"location": "pune"}
    - slot{"location_supported": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_search_restaurants
    - slot{"location": "pune"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* deny
    - utter_goodbye
    - action_restart
	
## interactive_story_price cuisine_location
* greet
    - utter_greet
* restaurant_search{"price": "Lesser than Rs. 300", "cuisine": "chinese", "location": "Delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Delhi"}
    - slot{"price": "Lesser than Rs. 300"}
    - verify_location
    - slot{"location": "Delhi"}
    - slot{"location_supported": true}
    - action_search_restaurants
    - slot{"location": "Delhi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* send_email
    - utter_ask_emailid
* restaurant_search{"emailid": "dwivedi.amit21982@gmail.com"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - action_send_email
    - form{"name": "action_send_email"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - slot{"emailid": "dwivedi.amit21982@gmail.com"}
    - form{"name": null}
    - slot{"requested_slot": null}
    - utter_goodbye
	
## interactive_story_price cuisine_location
* greet
    - utter_greet
* restaurant_search{"price": "Lesser than Rs. 300", "cuisine": "chinese", "location": "Delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Delhi"}
    - slot{"price": "Lesser than Rs. 300"}
    - verify_location
    - slot{"location": "Delhi"}
    - slot{"location_supported": true}
    - action_search_restaurants
    - slot{"location": "Delhi"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* deny
    - utter_goodbye
    - action_restart
	