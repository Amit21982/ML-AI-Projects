## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- thanks a lot

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one
- good night

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- hola
- good morning
- good afternoon
- good evening
- dear sir
- Hi
- [dilli]{"entity": "location", "value": "Delhi"}

## intent:send_email
- I had sent you a list of top 10 restaurents in [Delhi](location).
- I had sent you a list of top 10 restaurents in [Bangalore](location).
- I had sent you a list of top 10 Mexican restaurents in [Mumbai](location).
- Here is the list of top 10 restaurents in [Delhi](location).
- [dwivedi.amit21982@gmail.com](emailid)
- [headofstars@gmail.com](emailid)
- [amirasabot2020@gmail.com](emailid)
- [vishy007.geek@gmail.com](emailid)
- [kcmrocky@gmail.com](emailid)
- [my email is dwivedi.amit21982@gmail.com](emailid)

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chinese](cuisine) restaurants in the [New Delhi]{"entity": "location", "value": "Delhi"}
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called [olaolaolaolaolaola](location)
- I am starving please suggest some good chinese restaurants in Kolkata
- search for restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [American](cuisine)
- [Mexican](cuisine)
- [Italian](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- can you book a table in [rome](location) in a [moderate]{"entity": "price", "value": "mid"} price range with [british](cuisine) food for [four]{"entity": "people", "value": "4"} people
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurants in [bangalore](location)
- please help me to find restaurants in [Kollam](location)
- please help me to find restaurants in [Warangal](location)
- Looking for restaurants with price range [less than 300](price)
- Looking for restaurants in the range of [300 to 700](price)
- Looking for restaurants with price [more than 700](price)
- find high cost [north indian](cuisine) restaurants in [delhi](location)
- find italian restaurants between [300 to 700](price)
- find [south indian](cuisine) restaurants between [300 to 700](price)
- find [north indian](cuisine) restaurants between [300 to 700](price)
- find [mexican](cuisine) restaurants between [300 to 700](price)
- find [american](cuisine) restaurants between [700 to 500000](price)
- find [italian](cuisine) restaurants between [0 to 300](price)
- find [chinese](cuisine) restaurants with price range [less than 700](price)
- some [american](cuisine) restaurants in [lucknow](location)
- some good fine dine restaurants in [jaipur](location) for [price < 700](price)
- some good restaurants in [nagpur](location) with [price < 500](price)
- please find restaurants between price range of [300 - 700](price)
- find some food restaurants in [Bhopal](location) with [> 300 price](price)
- show me restaurants
- show me [lassi](cuisine) restaurants
- show me [dosa](cuisine) restaurants
- show me [vada](cuisine) restaurants
- show me [noodles](cuisine) restaurants
- show me [burger](cuisine) restaurants
- show me [pizzas](cuisine) restaurants
- show me [tacos](cuisine) restaurants
- some italian restaurants in mangalore
- Show me American restaurants in [dilli](location)
- Show me restaurants in [Madras](location)
- some sea food restaurants in Cochin
- please find me [chinese](cuisine) restaurant in [delhi](location)
- please find me [american](cuisine) restaurant in [kota](location)
- please find me [mexican](cuisine) restaurant in [pune](location)
- please find me [south indian](cuisine) restaurant in [chennai](location)
- please find me [north indian](cuisine) restaurant in [madurai](location)
- can you find me a [chinese](cuisine) restaurant
- can you find me a [mexican](cuisine) restaurant
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- find me a [Chinese]{"entity": "cuisine", "value": "chinese"} restaurent
- thanks a  lot for your help
- Great job, keep it up
- [Lesser than Rs. 300](price)
- [Rs. 0 to 300](price)
- [Rs. 300 to 700](price)
- [300 to 700](price)
- [Rs. 700 to 500000](price)
- [More than Rs. 300](price)
- [More than Rs. 700](price)
- [Greater than Rs. 300](price)
- [Greater than Rs. 700](price)
- [Between range Rs. 0 - Rs. 300](price)
- [Between range Rs. 300 - Rs. 700](price)
- [Between range Rs. 700 - Rs. 500000](price)
- [ahmedabad](location)
- [Mumbai](location)
- [mumbai](location)
- [Warangal](location)
- [Kollam](location)
- [Kota](location)
- [Jaipur](location)
- [Chennai](location)
- [delhi](location)
- [Jammu](location)
- [agra](location)
- [ajmer](location)
- [allahabad](location)
- [amravati](location)
- [amritsar](location)
- [asansol](location)
- [chandigarh](location)
- [coimbatore](location)
- [dehradun](location)
- [dhanbad](location)
- [gulbarga](location)
- [guntur](location)
- [guwahati](location)
- [indore](location)
- [jabalpur](location)
- [jalandhar](location)
- [jammu](location)
- [jamshedpur](location)
- [jodhpur](location)
- [kannur](location)
- [kakinada](location)
- [kottayam](location)
- [kochi](location)
- [kozhikode](location)
- [kurnool](location)
- [lucknow](location)
- [mathura](location)
- [goa](location)
- [pondicherry](location)
- [mangalore](location)
- [srinagar](location)
- [sultanpur](location)
- [thiruvananthapuram](location)
- [thrissur](location)
- [tiruchirappalli](location)
- [ujjain](location)
- [vadodara](location)
- [varanasi](location)
- in [Gurgaon](location)
- [dwivedi.amit21982@gmail.com](emailid)
- [vishy007.geek@gmail.com](emailid)
- [kcmrocky@gmail.com](emailid)
- [headofstars@gmail.com](emailid)
- [amirasabot2020@gmail.com](emailid)
- [my email is dwivedi.amit21982@gmail.com](emailid)
- search restaurant
- [pune](location)
- please find me [chinese](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}
- find restaurant in [mumbai]{"entity": "location", "value": "Mumbai"}
- find [cheap](price) restaurant in [mumbai]{"entity": "location", "value": "Mumbai"}
- find [pocket-friendly](price) restaurant in [mumbai]{"entity": "location", "value": "Mumbai"}
- find [economical](price) restaurant in [pune](location)
- find [low budget](price) restaurant in [chennai](location)
- search [cheap](price) restaurant in [mumbai]{"entity": "location", "value": "Mumbai"}
- search [moderate](price) restaurant in [mumbai]{"entity": "location", "value": "Mumbai"}
- search [expensive](price) restaurant in [pune](location)
- search [low cost](price) restaurant in [chennai](location)
- [American]{"entity": "cuisine", "value": "american"}
- find lassi restaurant
- find [moderate](price) restaurants
- find [cheap](price) restaurants
- find [expensive](price) restaurants
- find [costly](price) restaurants
- Show me American restaurants in dilli
- show me [lassi]{"entity": "cuisine", "value": "north indian"} restaurants
- show me [dosa]{"entity": "cuisine", "value": "south indian"} restaurants
- [madras]{"entity": "location", "value": "Chennai"}
- show me [noodles]{"entity": "cuisine", "value": "chinese"} restaurants
- [poona]{"entity": "location", "value": "pune"}
- show me [burger]{"entity": "cuisine", "value": "american"} restaurants
- Navi [Mumbai](location)
- show me [pizzas]{"entity": "cuisine", "value": "italian"} restaurants
- [calcutta]{"entity": "location", "value": "kolkata"}
- show me [tacos]{"entity": "cuisine", "value": "mexican"} restaurants
- [mysuru]{"entity": "location", "value": "mysore"}
- show me restaurants in [Madras]{"entity": "location", "value": "Chennai"}
- [Mexican]{"entity": "cuisine", "value": "mexican"}
- please find me restaurants in [London](location)
- [London](location)
- [dubai](location)
- [rajkot](location)
- [salem](location)
- [cuttack](location)
- search restaurants in [zinjhang](location)
- search restaurants in [dumboo](location)
- search restaurants in [paris](location)
- find [cheap]{"entity": "price", "value": "Lesser than Rs. 300"} restaurant in [mumbai]{"entity": "location", "value": "Mumbai"}
- find [costly]{"entity": "price", "value": "More than Rs. 700"} restaurant
- search [cheap]{"entity": "price", "value": "Lesser than Rs. 300"} [chinese](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}
- search [costly]{"entity": "price", "value": "More than Rs. 700"} [Italian](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}
- search [low budget]{"entity": "price", "value": "Lesser than Rs. 300"} [chinese](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}
- search [premium]{"entity": "price", "value": "More than Rs. 700"} [Italian](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}
- search [average]{"entity": "price", "value": "Rs. 300 to 700"} [chinese](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}
- search [moderate]{"entity": "price", "value": "Rs. 300 to 700"} [Italian](cuisine) restaurant in [delhi]{"entity": "location", "value": "Delhi"}

## synonym:2
- two
- 2 people
- couple

## synonym:4
- four

## synonym:Chennai
- madras
- Madras
- chennai
- Anna Nagar
- T Nagar

## synonym:Delhi
- dilli
- New Delhi
- delhi
- old delhi

## synonym:Hyderabad
- hyderabad
- Bangle City
- old City

## synonym:Lesser than Rs. 300
- cheap
- less than 300
- 0-300
- Between range Rs. 0 - Rs. 300
- price < 300
- low budget
- 0 to 300
- pocket-friendly
- economical
- low cost
- Lesser than Rs. 300

## synonym:More than Rs. 700
- costly
- more than 700
- greater than 700
- > 700
- price > 700
- high budget
- expensive
- 700 - 500000
- Costly
- Too pricy
- Very costly
- premium
- More than Rs. 700

## synonym:Mumbai
- mumbai
- Bombay
- Juhu Bandra Worli
- Navi Mumbai

## synonym:Rs. 300 to 700
- moderate
- less than 700
- lesser than 700
- 300-700
- Between range Rs. 300 - Rs. 700
- price < 700
- medium budget
- 300 to 700
- average
- normal
- good-cost
- medium range
- budget
- not so expensive
- not that expensive
- not very expensive
- Rs. 300 to 700

## synonym:american
- American
- burger
- Bagels
- American Salads
- hamburger
- hawaiian
- USA

## synonym:bangalore
- Bengaluru
- bengaluru
- B'lore
- Garden City

## synonym:chinese
- Chinese
- noodles
- chines
- Chines
- dumplings
- momos
- spring rolls
- schezwan
- chowmein
- chow mein

## synonym:italian
- pizzas
- bruschetta
- Italian
- margherita
- italiano
- caprese

## synonym:jaipur
- Jaipur
- Pink City

## synonym:jaisalmer
- Jaisalmer
- Golden City

## synonym:kolkata
- calcutta
- Kolkata
- Calcutta
- city of palaces

## synonym:mexican
- tacos
- Mexican
- Mexican food
- Tortilla
- Nachos
- quesadillas
- enchiladas
- burritos

## synonym:mysore
- mysuru
- Mysore
- Mysuru

## synonym:non-vegetarian
- non-veggie
- non-vegg
- non vegetarian
- chicken
- fish
- mutton
- sea food
- butter chicken

## synonym:north indian
- lassi
- parathas
- poori chole
- butter naan
- North
- roti curry
- baingan
- kashmiri
- rabdi

## synonym:pune
- poona
- Pune
- Poona

## synonym:south indian
- dosa
- vada, upma
- idly sambar
- Southern food
- thali

## synonym:vadodara
- Vadodara
- Baroda
- baroda

## synonym:vegetarian
- veggie
- vegg
- vegan
- Vegetarian

## synonym:visakhapatnam
- Visakhapatnam
- vizag
- vizagapatam

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}

## regex:send_email
- ^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$
