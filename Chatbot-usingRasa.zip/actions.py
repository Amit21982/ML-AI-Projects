from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import zomatopy
import json
from email.message import EmailMessage
import smtplib
from typing import Dict, Text, Any, List, Union, Optional
from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction
from rasa_sdk.events import (
    SlotSet,
    UserUtteranceReverted,
    ConversationPaused,
    EventType,
    FollowupAction,
)

#Global Variables Used later
email_sender = "amirasabot2020@gmail.com"
email_password = "Rasa@12345"
email_body = []
smtpserver = "smtp.gmail.com"
smtpport = 465
zomato_key = "f4924dc9ad672ee8c4f8c84743301af5"

tier1City = ['ahmedabad', 'bangalore', 'chennai','delhi', 'hyderabad', 'kolkata', 'mumbai', 'pune']
tier2City = ['agra', 'ajmer', 'aligarh', 'allahabad', 'amravati', 'amritsar', 'asansol', 'aurangabad',
           'bareilly', 'belgaum', 'bhavnagar', 'bhiwandi', 'bhopal', 'bhubaneswar', 'bikaner',
           'bokaro steel city', 'chandigarh', 'coimbatore', 'cuttack', 'dehradun', 'dhanbad',
           'durg-bhilai nagar', 'durgapur', 'erode', 'faridabad', 'firozabad', 'ghaziabad', 'gorakhpur',
           'gulbarga', 'guntur', 'gurgaon', 'guwahati', 'gwalior', 'hubli-dharwad', 'indore', 'jabalpur',
           'jaipur', 'jalandhar', 'jammu', 'jamnagar', 'jamshedpur', 'jhansi', 'jodhpur', 'kannur',
           'kanpur', 'kakinada', 'kochi','kottayam', 'kolhapur', 'kollam', 'kota', 'kozhikode', 'kurnool',
           'lucknow', 'ludhiana','madurai', 'malappuram', 'mathura', 'goa', 'mangalore', 'meerut', 'moradabad',
           'mysore','nagpur', 'nanded', 'nashik', 'nellore', 'noida', 'palakkad', 'patna', 'pondicherry', 'raipur',
           'rajkot', 'rajahmundry', 'ranchi', 'rourkela', 'salem', 'sangli', 'siliguri', 'solapur',
           'srinagar', 'sultanpur', 'surat', 'thiruvananthapuram', 'thrissur', 'tiruchirappalli',
           'tirunelveli', 'tiruppur', 'ujjain', 'vijayapura', 'vadodara', 'varanasi', 'vasai-virar city',
           'vijayawada', 'visakhapatnam', 'vellore','warangal']

class ActionSearchRestaurants(Action):
    def name(self):
        return 'action_search_restaurants'

    def returncostrange(self, cost_option):
        cost_range = [0, 0]
        if cost_option == 1:
            cost_range = [0, 300]
        elif cost_option == 2:
            cost_range = [300, 700]
        elif cost_option == 3:
            cost_range = [700, 500000]
        return cost_range

    def sortbyrating(self, budgRest):
        budget_rating_sorted = sorted(budgRest, key=lambda entry: entry['restaurant']['user_rating']['aggregate_rating'], reverse=True)
        return budget_rating_sorted


    def filterByPrice(self, cost_choice, restaurant_list):
        cost_dict = {'Lesser than Rs. 300': 1, 'Rs. 300 to 700': 2, 'More than Rs. 700': 3}
        response = ''
        cost_option = cost_dict.get(cost_choice)
        cost_range = self.returncostrange(cost_option)
        count = 0

        budgRest = []
        for restaurant in restaurant_list:
            if restaurant['restaurant']["average_cost_for_two"] >= cost_range[0] and restaurant['restaurant']["average_cost_for_two"] <= cost_range[1]:
                budgRest.append(restaurant)

        budget_rating_sorted = self.sortbyrating(budgRest)
        return budget_rating_sorted


    def run(self, dispatcher, tracker, domain):

        cuisine = tracker.get_slot('cuisine')
        loc = tracker.get_slot('location')
        price_range = tracker.get_slot('price')

        config = {"user_key":zomato_key}
        zomato = zomatopy.initialize_app(config)
        location_detail = zomato.get_location(loc, 1)
        d1 = json.loads(location_detail)
        lat = d1["location_suggestions"][0]["latitude"]
        lon = d1["location_suggestions"][0]["longitude"]
        cuisines_dict = {'american': 1, 'chinese': 25, 'mexican': 73, 'italian': 55, 'north indian': 50, 'south indian': 85}
                         
        results = zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), 10000)
        d = json.loads(results)
        
        response = ""
        if d['results_found'] == 0:
            restaurant_present = False
            dispatcher.utter_message("Sorry, no Restaurant found this location:(" + "\n")
        else:
            sorted_restaurant_list = self.filterByPrice(price_range, d['restaurants'])

        if len(sorted_restaurant_list) == 0:
            restaurant_present = False
            dispatcher.utter_message("Sorry, no resturantes found :(" + "\n")
        else:
            # Pick the top 5
            sorted_restaurant_list_5 = sorted_restaurant_list[:5]
            
            #We also have to send email in case email action is chosen
            global email_body
            email_body = sorted_restaurant_list[:10]
            if (email_body and len(email_body) > 0):
                restaurant_present = True

            for restaurant in sorted_restaurant_list_5:
                response = response + restaurant['restaurant']['name'] + " in " + restaurant['restaurant']['location'][
                    'address'] + \
                           " has been rated " + \
                           restaurant['restaurant']['user_rating']['aggregate_rating'] + "\n" + "\n"
            dispatcher.utter_message("Here are our picks!" + "\n" + response)
        return [SlotSet('location', loc), SlotSet('restaurant_exist', restaurant_present)]

class VerifyRegion(Action):
    Region_1 = []
    Region_2 = []

    def __init__(self):
        global  tier1City
        global tier2City
        self.Region_1 = tier1City
        self.Region_2 = tier2City

    def name(self):
        return "verify_location"

    def run(self, dispatcher, tracker, domain):
        loc = tracker.get_slot('location')
        dispatcher.utter_message("You have selected ==> " + str(loc))
        if not (self.verify_location(loc)):
    ##    if loc not in tier1City or tier2City: 
            dispatcher.utter_message(" Currently we do not operate in " + str(loc) + ",Please select a valid city.")
            return [SlotSet('location', None), SlotSet("location_supported", False)]
        else:
            return [SlotSet('location', loc), SlotSet("location_supported", True)]

    def verify_location(self, loc):
        return str(loc).lower() in self.Region_1 or str(loc).lower() in self.Region_2


class ActionEmail(FormAction):
    def name(self):
        return 'action_send_email'

    @staticmethod
    def required_slots(tracker) -> List[Text]:
        return ["emailid"]

    def slot_mappings(self) -> Dict[Text, Union[Dict, List[Dict]]]:
        return {
            "email": [
                self.from_entity(entity="emailid"),
            ]
        }

    def submit(self,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any],) -> List[EventType]:
        global smtpserver
        global smtpport
        global email_sender
        global email_password

        send_to_email = tracker.get_slot('emailid')
        loc = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')

        global email_body
        count = len(email_body)
        
        # Construct the email 'subject' and the contents.
        subj = "Top " + str(count) + " " + cuisine.capitalize() + " restaurants in " + str(
            loc).capitalize()
        msg = ("From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n"
               % (email_sender, ", ".join(send_to_email), subj))

        msg = msg + "Hello, " + "\n" +"Please refer the " + subj + "." + "\n" + "\n"
        
        for restaurant in email_body:
            msg = msg + restaurant['restaurant']['name'] + " in " + \
                          restaurant['restaurant']['location']['address'] + " has been rated " + \
                          restaurant['restaurant']['user_rating']['aggregate_rating'] + " with average cost for two Rs " +\
                          str(restaurant['restaurant']["average_cost_for_two"]) + "\n"
                           
                        
        msg = msg + "Regards,"  + "\n" + "Restaurant Chatbot"+ "\n"

        #Setup the connection
        s = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        s.set_debuglevel(1)
        s.ehlo()
        s.login(email_sender, email_password)
        s.sendmail(email_sender, send_to_email, msg)

        s.quit()
    ###    dispatcher.utter_message("Email is sent to you mentioned email address!!!")
        return []


